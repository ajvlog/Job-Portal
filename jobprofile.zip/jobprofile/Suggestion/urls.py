from django.urls import path
from . import views
urlpatterns=[

    path('showform1/',views.showform1,name='showform1'),
]