from django.shortcuts import render

from .models import MyModel
from .forms import MyForm


# Create your views here.


def showform1(request):
    if request.method == "POST":
        form=MyForm(request.POST)
        if form.is_valid():
            form.save()
    else:
        form = MyForm()
    return render(request,  'a6.html', {'form': form})