from django.apps import AppConfig


class SuggestionConfig(AppConfig):
    name = 'Suggestion'
