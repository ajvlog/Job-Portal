from django.db import models

# Create your models here.




class MyModel(models.Model):
    comment= models.TextField()