from django.shortcuts import render

from .forms import JobForm


def showform(request):
    form = JobForm(request.POST or None)
    if form.is_valid():
        form.save()

    context = {'form': form}

    return render(request, 'a.html', context)

def showform2(request):
    form = JobForm(request.POST or None)
    if form.is_valid():
        form.save()

    context = {'form': form}

    return render(request, 'a9.html', context)

def showform3(request):
    form = JobForm(request.POST or None)
    if form.is_valid():
        form.save()

    context = {'form': form}

    return render(request, 'a10.html', context)

def index(request):
    return render(request, 'a1.html')

def index1(request):
    return render(request, 'a2.html')

def index2(request):
    return render(request,  'a3.html')

def index3(request):
    return render(request,  'a4.html')

def index4(request):
    return render(request,  'a5.html')

def index5(request):
    return render(request, 'a7.html')

def index6(request):
    return render(request, 'a8.html')

