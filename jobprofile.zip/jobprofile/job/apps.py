from django.apps import AppConfig


class JobConfig(AppConfig):
    name = 'job'
